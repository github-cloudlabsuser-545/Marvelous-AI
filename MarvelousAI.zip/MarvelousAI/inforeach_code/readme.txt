1.Create env variable
 python -m venv ./venv
./venv/Scripts/activate
2.Run the app
 streamlit run main.py