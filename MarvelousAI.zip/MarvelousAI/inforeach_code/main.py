import os
import base64
import streamlit as st
from utils import CreateRAG

cr=CreateRAG()

def user_input(user_question):
    llm = cr.load_llm()
    chain=cr.search(llm)
    result=chain.invoke({"question":user_question})
    return result
    
def main():
    st.set_page_config(layout="wide",page_title="Quick & efficient retreival of context aware search results and relevant information", page_icon="🧊")
    hide_menu_style = """
        <style>
        #MainMenu {visibility: hidden; }
        footer {visibility: hidden;}
        </style>
        """
    st.markdown(hide_menu_style, unsafe_allow_html=True)
    @st.cache_data
    def set_background(png_file):
        with open(png_file, "rb") as f:
            img_data = f.read()
            bin_str = base64.b64encode(img_data).decode()
        page_img = f'<img src="data:image/jpg;base64,{bin_str}" style="position: fixed; top: 220px; left: 5px; width: 170%; height: 60%; object-fit: scale-down;">'
        st.markdown(page_img, unsafe_allow_html=True)
    set_background('background.png')
    
    st.markdown(
    """
    <div style='overflow: auto;'>
        <h3 style='color: black; padding: 1px; font-family: Arial, sans-serif;'>Knowledge mining of Engineering documents</h3>
        <h3 style='color: red; padding: 1px;margin: 0 auto; font-family: Arial, sans-serif; text-align: center;'>&</h3>
        <h3 style='color: black; padding: 1px; font-family: Arial, sans-serif;'>Streamline Employee Onboarding Process!!</h3>
    </div>
    """,
    unsafe_allow_html=True
    )

    label = "Please ask your question here!!💁"
    custom_css = '''
    <style>
        textarea.stTextArea {
          width: 200px;
        }
    </style>
    '''
    st.markdown(custom_css, unsafe_allow_html=True)
    col1, col2= st.columns(2)
    with col1:
        with st.form("my-form",border=False):
            user_question = st.text_area(label,height=100)
            st.form_submit_button(":black[Submit question]")
    with col2:
        st.write(' ')
    result = None  # Initialize result outside the if block

    if user_question:
        with st.spinner("Processing your question..."):
            result=user_input(user_question)  # Handle user input and start a conversation
    if result is not None:
        col1, col2= st.columns(2)
        with col1:
            for line in result.splitlines():  
                if len(line) > 0:  
                    st.write(line)
        with col2:
            st.write(' ')
       
    with st.sidebar:
        st.title(":yellow[Upload latest documents for Search:] :open_book:")
        pdf_docs = st.file_uploader("Upload the file in PDF format and Click on the Submit & Process Button", accept_multiple_files=True,type=["pdf"])

        if st.button("Submit & Process"):
            with st.spinner("Operation in progress. Please wait..."):
                final_pdf_docs=[]
                for file in pdf_docs:
                    if file.name.endswith(('.pdf', '.PDF')):
                       final_pdf_docs.append(file)
                    else:
                        st.error(f"File format is not supported for uploaded file: {file.name}", icon="🚨")

                if final_pdf_docs:
                    for pdffile in final_pdf_docs:
                        with open(os.path.join("tmpDir",pdffile.name),"wb") as f:
                            f.write(pdffile.getbuffer())
                            st.success(f"File {pdffile.name} saved successfully.",icon="✅")
                            
                    documents=cr.get_pdf_text(final_pdf_docs)
                    llm = cr.load_llm()
                    cr.add_graph_db(llm,documents)
                    st.success("Upload is successfully completed. Kindly ask the questions now!!",icon="✅")

if __name__ == "__main__":
    main()

   