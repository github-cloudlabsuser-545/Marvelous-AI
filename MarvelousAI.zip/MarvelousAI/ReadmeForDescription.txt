-inforeach_code
--This folder contains the main code for our RAG Application hosted in streamlit.
  To execute the code:
  1.Create env variable
 	python -m venv ./venv
	./venv/Scripts/activate
  2.Run the app
 	streamlit run main.py

-graph_and_evaluation
 --streamlit_dashboard
	We have included the pdfs for the snapshot of the app hosted in streamlit.It shows the UI for the target users.
 --Metadata_for_documents
	It provides the metadata(json format) for all the documents which were used in creating knowledge graph.Using metadata it becomes easy to validate the 	information provided by LLM, as it trace back to the source document.Each citation provided by LLM can 	be traced back to source document .Metadata 	also provide page number, language as well as type of object as text or image.
 --colab_notebook
   --Knowledge_Graph_Visualization_Notebook
	This contains the colab notebook that represents the code for visualizing knowledgegraph data model created in neo4j graph database.
   --RAG_Evaluation_Notebook
	This contains the colab notebook and files that were used for tracking and evaluation of our RAG application where we have used Truelens which is an    	Evaluation Framework that allows to collect quantifiable metrics for the RAG system performance, also it provide the leaderboard for visualizing the 	result of these metrics for different version of our application which is hosted on Streamlit.
